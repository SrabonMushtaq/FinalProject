<?php
	include('header.php');
	if(mysqli_num_rows($ses_sql) == 1){
		echo $user_name;
	}	
	else{
		header('Location: login.php');
	}
?>