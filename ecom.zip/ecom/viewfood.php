<?php
  include('header.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/viewfood.css">
  <title>View Food</title>
</head>
<body>
  <?php
    if(isset($_REQUEST['foodid'])){
      $foodId = $_REQUEST['foodid'];
      $viewFood = "SELECT * FROM food_info where food_id = '$foodId' ";
      $viewResult = mysqli_query($conn, $viewFood);
      if(mysqli_num_rows($viewResult) == 1){

        $foodDes = mysqli_fetch_assoc($viewResult);

        ?>
        <div class="view-container">
          <div class="view-header">
              <h3>Food - <?php echo $foodDes['food_name']; ?></h3>
          </div>

          <div class="view-img">
            <img src="admin/uploads/<?php echo $foodDes['food_image']; ?>" alt="">
          </div>

          <div class="view-des">
            <p><?php echo $foodDes['food_name']; ?></p>
            <p><?php echo $foodDes['food_price']; ?></p>
            <a href="checkout.php?id=<?php echo $foodDes['food_id']; ?>">Order Now</a>
          </div>
        </div>

        <?php
      }
      //for no result statement
      elseif(mysqli_num_rows($viewResult) == 0){
        ?>
          <h1 align ="center">No Result Found For Your Request</h1>
        <?php

      }

    }
    elseif(empty($_REQUEST['foodid'])){
      header('Location: food.php');
    }



  ?>

</body>
</html>
