<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<style>
		table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 50%;
		}

		td, th {
				border: 1px solid #dddddd;
				text-align: left;
				padding: 8px;
		}

		tr:nth-child(even) {
				background-color: #dddddd;
		}
	
	</style>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<form action="" method="post">
		Name: <input type="text" name="name" /><br />
		Age: <input type="text" name="age" /><br />
		Adress: <input type="text" name="adress" /><br />
		        <input type="submit" name="click" />
	</form>
	<br />
	<br />
	
</body>
</html>
<?php

	require_once('conn.php');

	if(isset($_POST['click'])){
		
		$name =  $_POST['name'];
		
		$age = $_POST['age'];
		
		$adress = $_POST['adress'];
		
		$query = "INSERT INTO info (name, age, adress)
				VALUES ('$name', '$age', '$adress') ";
				
		if (mysqli_query($conn, $query)) {
			echo "ডাটাবেজে সেটে দেওয়া হয়েছে।";
		} 
		
		else {
			echo "Error: " . $query . "<br>" . mysqli_error($conn);
		}
		
		

		
	}
	//ডাটা শো
		
		$view = "SELECT * FROM info";
		$result = mysqli_query($conn, $view);

		if (mysqli_num_rows($result) > 0) {
			?>
			<br />
			<br />
			<br />
			<table>
				  <tr>
					<th>Name</th>
					<th>Age</th>
					<th>Adress</th>
				  </tr>
			<?php
    
			while($row = mysqli_fetch_assoc($result)) {
				$view_name = $row["name"];
				$view_age = $row["age"];
				$view_adress = $row["adress"];
				?>
				
				  <tr>
					<td><?php echo $view_name; ?></td>
					<td><?php echo $view_age; ?></td>
					<td><?php echo $view_adress; ?></td>
				  </tr>
				  
				
				
				<?php
			}
			?>
			</table>
			<?php
		} 
		else {
			echo "0 results";
		}
	mysqli_close($conn);
?>


