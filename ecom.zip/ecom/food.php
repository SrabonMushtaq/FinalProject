<?php
	include('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Home</title>
	<link rel="stylesheet" href="css/index.css">
</head>
<body>
	<!-- here your contetnt -->

			<?php
			$foodView = "SELECT * FROM food_info";
			$foodResult = mysqli_query($conn, $foodView);
			if(mysqli_num_rows($foodResult) > 0){
				?>
			<div class="row">
			<?php

				while($rowFood = mysqli_fetch_assoc($foodResult)){
					$foodId = $rowFood['food_id'];
					$foodName = $rowFood['food_name'];
					$foodPrice = $rowFood['food_price'];
					$foodImage = $rowFood['food_image'];
					?>
					<div class="column">
						<img src="admin/uploads/<?php echo $foodImage; ?>" alt="<?php echo $foodName; ?>">
				    <a href="viewfood.php?foodid=<?php echo $foodId; ?>"><?php echo $foodName; ?></a>
				    <p><?php echo $foodPrice; ?></p>
				  </div>
					<?php
				}
			}

			?>

			</div>
			

</body>
</html>
