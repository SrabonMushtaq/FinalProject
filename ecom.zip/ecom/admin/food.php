<?php
	include('session.php');
	include('header.php');

	$msg_name = "1";
	$msg_price = "1";
	$msg_image = "1";
	$suc_msg = "0";

	if(isset($_POST['insert_food'])){

		if(empty($_POST['food_name'])){

			$msg_name = "2";


		}
		if(empty($_POST['food_price'])){
			$msg_price = "2";


		}
		if(empty($_FILES['food_image']['name'])){
			$msg_image = "2";


		}
		else{
			$food_name = $_POST['food_name'];
			$food_price = $_POST['food_price'];

			$file = rand(1000,100000)."-".$_FILES['food_image']['name'];
			$file_loc = $_FILES['food_image']['tmp_name'];
			$file_size = $_FILES['food_image']['size'];
			$file_type = $_FILES['food_image']['type'];
			$folder="uploads/";
			move_uploaded_file($file_loc,$folder.$file);

			$food_query = "INSERT INTO food_info (food_name, food_price, food_image, food_image_size) VALUES ('$food_name', '$food_price', '$file', '$file_size') ";

			if (mysqli_query($conn, $food_query)) {
			$suc_msg = "1";
			}

			else{
			echo "Error: " . $food_query . "<br>" . mysqli_error($conn);
			}
		}


	}

?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="css/food.css" class="css" />
</head>
<body>

		<div class="main_content">

			<div class="insert_name">Add A Food Item
			<br />

			</div>
			<div class="insert">
			<?php if($suc_msg == 1){ echo "Added"; } ?>
				<form action="" method="post" enctype="multipart/form-data">

					<table>
						<tr>
							<td class="">Name</td>
							<td><input type="text" class="" name="food_name" />
							<?php if($msg_name == 2){ echo"Plese Enter Name"; } ?>


							</td>
						</tr>
						<tr>
							<td>Price</td>
							<td><input type="text"  name="food_price"/>
							<?php if($msg_price==2){ echo"Plese Enter Price"; } ?>

							</td>


						</tr>

						<tr>
							<td>Image</td>
							<td><input type="file" name="food_image" />
							<?php if($msg_image==2){ echo"Plese Select An Image"; } ?>

							</td>
						</tr>
						<tr>
							<td></td>
							<td><input type="submit"  value="Insert" name="insert_food">

							</td>
						</tr>
					</table>


				</form>

			</div>


		</div>

		<div class="view_food">
		<div class="view_heading">ALL Food Item</div>

				<?php
				$food_view = "SELECT * FROM food_info";
				$food_result = mysqli_query($conn, $food_view);
				if(mysqli_num_rows($food_result) > 0){
					?>
					<table>
						<tr>
							<th>Name</th>
							<th>Price</th>
							<th>Action</th>
						</tr>

						<?php

							while($row_food = mysqli_fetch_assoc($food_result)) {
								$view_food_name = $row_food["food_name"];
								$view_food_price = $row_food["food_price"];
								$view_food_id = $row_food["food_id"];
								?>

								  <tr>
									<td><?php echo $view_food_name; ?></td>
									<td><?php echo $view_food_price; ?></td>
									<td><a href="view_food.php?id=<?php echo $view_food_id; ?>">View</a></td>
								  </tr>



							<?php
						}
						?>

					</table>
				<?php
				}
				elseif(mysqli_num_rows($food_result) == 0){
					?>
					<h1>Records Not Found!</h1>
					<?php
				}

				?>


		</div>

</body>
</html>
