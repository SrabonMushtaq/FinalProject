<?php
   include('conn.php');
   session_start();
   
   $user_check = $_SESSION['uname'];
   
   $ses_sql = mysqli_query($conn,"select * from admin_info where uname = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $admin_name = $row['uname'];
   
   if(!isset($_SESSION['uname'])){
      header("location: login.php");
   }
?>