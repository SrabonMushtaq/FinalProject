<?php
	include('session.php');
	include('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>User</title>
	<link rel="stylesheet" href="css/user.css">
</head>
<body>
	<div class="view_user">
		<div class="view_heading">ALL Order</div>

				<?php
				$order_view = "SELECT * FROM checkout";
				$order_result = mysqli_query($conn, $order_view);
				if(mysqli_num_rows($order_result) > 0){
					?>
					<table>
						<tr>
							<th>Food Name</th>
							<th>Price</th>
							<th>Biller Name</th>
							<th>User Name</th>
							<th>Biller Email</th>
							<th>Biller Adress</th>
							<th>Biller Contact</th>
							<th>Order Date</th>
							<th>Status</th>
							<th>Action</th>
							
						</tr>
						<?php 
							while($rowOrder = mysqli_fetch_assoc($order_result)){
										$foodmsg = 0;
										$usermsg = 0;
										$foodId = $rowOrder['food_id'];
										$userId = $rowOrder['user_id'];
										$foodResult = mysqli_query($conn, "select * from food_info where food_id ='$foodId' ");
										$userResult = mysqli_query($conn, "select * from user_info where user_id ='$userId' ");
										if(mysqli_num_rows($foodResult)>0){
											$foodInfo = mysqli_fetch_assoc($foodResult);
											$foodmsg = 1;
										}
										if(mysqli_num_rows($userResult)>0){
											$userInfo = mysqli_fetch_assoc($userResult);
											$usermsg = 1;
										}

									 ?>
							


								  <tr>
									<td><?php if($foodmsg == 1){echo ucwords($foodInfo['food_name']);}
											else{
												echo "NULL";
											}
									 ?></td>
									<td><?php if($foodmsg == 1){echo ucwords($foodInfo['food_price']);}
											else{
												echo "NULL";
											}
									 ?></td>
									<td><?php echo ucwords($rowOrder['name']); ?></td>
									<td><?php if($usermsg == 1){echo ucwords($userInfo['user_name']);}
											else{
												echo "Non User";
											}
									 ?></td>
									 <td><?php echo $rowOrder['mail']; ?></td>
									 <td><?php echo $rowOrder['adress']; ?></td>
									 <td><?php echo $rowOrder['contact']; ?></td>
									 <td><?php echo $rowOrder['checkdate']; ?></td>
									 <td><?php echo $rowOrder['status']; ?></td>
									 <td><a href="editorder.php?id=<?php echo $rowOrder['id']; ?>">Edit</a></td>

								  </tr>
						<?php
							}
				
						?>

					</table>
				<?php
				}
				elseif(mysqli_num_rows($order_result) == 0){
					?>
					<h1>Records Not Found!</h1>
					<?php
				}

				?>


		</div>
	
</body>
</html>