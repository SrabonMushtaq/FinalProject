<?php
	include('session.php');
	include('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Home Page</title>
	<link rel="stylesheet" href="css/index.css">
	<style>
		
	.wrap{
    margin: 20px 10% 20px 10%;
    background: #f2f2f2;
    padding: 10px 0px 10px 20px;
    border: 1px solid #d5d5d5;
    border-radius: 8px;
    font-size: 22px;

}

.summary{
    margin: 20px 30% 20px 30%;
    background: #f2f2f2;
    padding: 10px 0px 10px 20px;
    border: 1px solid #d5d5d5;
    border-radius: 8px;
    font-size: 17px;

}
	</style>
</head>
<?php
	function queryAll($conn, $table){
		$queryAll = mysqli_query($conn, "select * from $table");
		$numRow = mysqli_num_rows($queryAll);
		echo $numRow;
	}
	function queryCondition($conn, $table, $field, $value){
		$queryAll = mysqli_query($conn, "select * from $table where $field ='$value'");
		$numRow = mysqli_num_rows($queryAll);
		echo $numRow;
	}
	function sumAll($conn, $table, $value){
		$total = 0;
		$queryAll = mysqli_query($conn, "select * from $table");
		if(mysqli_num_rows($queryAll)>0){
			while($row = mysqli_fetch_assoc($queryAll)){
				$total += $row[$value];
			}

		}
		echo $total;
	}
?>
<body>
	<p class="wrap">Summary At A Glance</p>
	<p class="summary">Total Food Item : <?php queryAll($conn, "food_info"); ?></p>
	<p class="summary">Total User : <?php queryAll($conn, "user_info"); ?></p>
	<p class="summary">Total Order : <?php queryAll($conn, "checkout"); ?></p>
	<p class="summary">Todays Order : <?php queryCondition($conn, "checkout", 'checkdate',date("Y-m-d")); ?></p>
	<p class="summary">Total Completed Order: <?php queryCondition($conn, "checkout", 'status','complete'); ?></p>
	<p class="summary">Total Pending Order: <?php queryCondition($conn, "checkout", 'status','pending'); ?></p>
	<p class="summary">Total  Cancelled Order: <?php queryCondition($conn, "checkout", 'status','cancel'); ?></p>
	<p class="summary">Total  Product In Ammount : <?php sumAll($conn, "food_info", 'food_price'); ?></p>
	

	
</body>
</html>
