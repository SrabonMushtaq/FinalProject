<?php
	include('session.php');
	include('header.php');
	if(isset($_REQUEST['id'])){
		$stid = $_REQUEST['id'];
		if(isset($_POST['update'])){
			$upstatus = $_POST['status'];
			$upquery = "UPDATE checkout SET status = '$upstatus' WHERE id = '$stid' ";
			if(mysqli_query($conn, $upquery)){
				echo "<script>alert('Update Successfully');</script>";
			}
		}

		
		$stquery = mysqli_query($conn, "select * from checkout where id ='$stid'");
		if(mysqli_num_rows($stquery)>0){
			$stResult = mysqli_fetch_assoc($stquery);
			?>
				<!DOCTYPE html>
				<html lang="en">
				<head>
					<meta charset="UTF-8">
					<title>Edit Order</title>
					<style>
						.edit{
							border: 1px solid lightgray;
							border-radius: 8px;
							margin: 20px 20% 0px 20%;

						}
						.heading{
							background-color: #f2f2f2;
							padding: 10px 20px 10px 10px;
							margin: 0
						}
						table{
							padding: 20px 20px 20px 80px;
						}
						td{
							padding: 20px;
							font-size: 17px;
						}
						select{
							height: 25px;
							width: 160px;
						}
						input{
							width: 160px;
							height: 25px;
							border: none;
							background: #333;
							color: #fff;
							cursor: pointer;
						}
					</style>
				</head>
				<body>
					<div class="edit">
						
						<h2 class="heading">Edit Order Status</h2>
						<form action="" method="post">
							<table>
								<tr>
									<td>Status</td>
									<td><select name="status" id="">
										<option value="pending" <?php if($stResult['status'] == "pending"){echo "selected"; } ?>>Pending</option>
										<option value="complete" <?php if($stResult['status'] == "complete"){echo "selected"; } ?> >Complete</option>
										<option value="cancel" <?php if($stResult['status'] == "cancel"){echo "selected"; } ?> >Cancel</option>
									</select></td>
								</tr>
								<tr>
									<td></td>
									<td><input type="submit" name="update" value="Update"></td>
								</tr>
								
							</table>
						</form>

					</div>
				</body>
				</html>
			<?php

		}
	}

?>
