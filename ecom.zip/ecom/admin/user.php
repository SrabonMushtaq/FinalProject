<?php
	include('session.php');
	include('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>User</title>
	<link rel="stylesheet" href="css/user.css">
</head>
<body>
	<div class="view_user">
		<div class="view_heading">ALL User</div>

				<?php
				$user_view = "SELECT * FROM user_info";
				$user_result = mysqli_query($conn, $user_view);
				if(mysqli_num_rows($user_result) > 0){
					?>
					<table>
						<tr>
							<th>Name</th>
							<th>Email</th>
							<th>Password</th>
							<th>Total Order</th>
							
						</tr>
						<?php 
							while($rowUser = mysqli_fetch_assoc($user_result)){
						?>	
								  <tr>
									<td><?php echo ucwords($rowUser['user_name']); ?></td>
									<td><?php echo $rowUser['user_mail']; ?></td>
									<td><?php echo $rowUser['user_pass']; ?></td>
									<td>
									<?php 
										$uId = $rowUser['user_id'];
										$totalOrder = mysqli_query($conn, "select * from checkout where user_id ='$uId' ");
										echo mysqli_num_rows($totalOrder);

									?>

									</td>

								  </tr>
						<?php
							}
				
						?>

					</table>
				<?php
				}
				elseif(mysqli_num_rows($user_result) == 0){
					?>
					<h1>Records Not Found!</h1>
					<?php
				}

				?>


		</div>
	
</body>
</html>