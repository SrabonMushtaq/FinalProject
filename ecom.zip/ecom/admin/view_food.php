<?php
	include('session.php');
	include('header.php');
	
	if(isset($_POST['edit'])){
		$errmsg = 0;
		$invalid = "`";
		$pname = $_POST['e_name'];
		$pprice = $_POST['e_price'];
		$pimage = $_FILES['e_image']['name'];
		$psize = $_FILES['e_image']['size'];
		$pid = $_POST['e_id'];
		if(empty($pname)){
			$errmsg = 1;
			$invalid = $invalid."Name must be required\n";
		}
		if(empty($pprice)){
			$errmsg = 1;
			$invalid = $invalid."Price must be required\n";
		}
		if(empty($pimage)){
			$errmsg = 1;
			$invalid = $invalid."Please upload a photo\n";
		}
		if($errmsg == 1){
			$invalid = trim($invalid."`");
			echo "<script>alert(".$invalid.");</script>";
		}
		elseif($errmsg == 0){

			$file = rand(1000,100000)."-".$pimage;
			$file_loc = $_FILES['e_image']['tmp_name'];
			$folder="uploads/";
			if(move_uploaded_file($file_loc,$folder.$file)){
				$uquery = "UPDATE food_info SET food_name = '$pname', food_price = '$pprice', food_image = '$file', food_image_size = '$psize' WHERE food_id = '$pid' ";
				if(mysqli_query($conn, $uquery)){
					echo "<script>alert('update successfully');</script>";
				}
			}
			
			
		}
		

	}
	if(isset($_POST['delete'])){
		$did = $_POST['e_id'];
		if(mysqli_query($conn, "DELETE FROM food_info WHERE food_id = '$did' ")){
				echo "<script>alert('deleted susccessfully');
					window.location.href='food.php';
					</script>";
		}
	}

	if(isset($_REQUEST['id'])){
		
		$food_id = $_REQUEST['id'];
		$food_view = "SELECT * FROM food_info WHERE food_id = '$food_id' ";
		$food_result = mysqli_query($conn, $food_view);
		if(mysqli_num_rows($food_result) == 1){
			$row_food = mysqli_fetch_assoc($food_result);
			$e_name = $row_food['food_name'];
			$e_id = $row_food['food_id'];
			$e_price = $row_food['food_price'];
			$e_image = $row_food['food_image'];
			?>
			<link rel="stylesheet" href="css/view_food.css" class="css" />
			<div class="main_content">
				<div class="heading">Food Description</div>
				<div class="action_des">
					<div class="food_action">
						<form action="" method="post" enctype="multipart/form-data">
							<table>
								<tr>
									<td>Name</td>
									<td><input type="text" name="e_name" class="einput" value="<?php echo $e_name; ?>" id="" /></td>
								</tr>
								<tr>
									<td>Price</td>
									<td><input class="einput" type="text" name="e_price" value="<?php echo $e_price; ?>" id="" /></td>
								</tr>
								<tr>
									<td>Image</td>
									<td><input type="file" name="e_image" class="eimage" id="" /></td>
								</tr>
								
								<tr>
									<td></td>
									<td>
										<input type="submit" name="edit" class="edit" value="Edit" />
										<input type="hidden" name="e_id" value="<?php echo $e_id; ?>">
										<input type="submit" name="delete" class="delete" value="Delete" />
									</td>
								</tr>
							</table>
						
						
						</form>
					
					</div>
					<div class="food_des">
						<img src="uploads/<?php echo $e_image; ?>" alt="" />
						<div class="price_name">
							<h1><?php echo $e_name; ?></h1>
							<h2><?php echo $e_price." "; ?>BDT</h2>
						
						</div>
					</div>
				</div>
			</div>
			<?php
		}
		if(mysqli_num_rows($food_result) == 0){
			echo "<h1 align='center'>Page Not Found!</h1>";
		}
	}
	elseif(empty($_REQUEST['id'])){
		header('location:food.php');
	}
	
	else{
		header('location:food.php');
	}

?>