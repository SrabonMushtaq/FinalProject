
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/header.css">
<style>

</style>
</head>
<body>

<div class="navbar">
  <a href="index.php">Home</a>
  <div class="dropdown">
    <button class="dropbtn">Management 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="food.php">Food</a>
      <a href="user.php">User</a>
      <a href="order.php">Order</a>
    </div>
  </div> 
  
  <div class="dropdown">
	
		<button class="dropbtn"><?php echo ucwords($admin_name); ?> 
		  <i class="fa fa-caret-down"></i>
		</button>
		<div class="dropdown-content">
		  
		  <a href="logout.php">Logout</a>
		
	</div>
  </div> 
</div>
</body>
</html>
