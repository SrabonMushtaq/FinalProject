
<?php

	include('conn.php');
	
	session_start();
	
	if(isset($_POST['confirm'])){
		
		if(isset($_POST['uname']) && isset($_POST['psw'])){
			
			$uname = $_POST['uname'];
			
			$psw = $_POST['psw'];
			
			$sql_login = "SELECT * FROM user_info WHERE user_name = '$uname' and user_pass = '$psw'";
			$user_result = mysqli_query($conn,$sql_login);
			
			$row = mysqli_fetch_array($user_result,MYSQLI_ASSOC);
			
			
			
			$count = mysqli_num_rows($user_result);
			
			if($count == 1) {
			
				$_SESSION['uname'] = $uname;
			 
				header('Location: index.php');
			}
			
			else {
				 $error = "Your Login Name or Password is invalid";
				 echo $error;
				 
			}
		}
	}



?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/login.css" class="css" />
</head>
<body>


<div class="mainpage">
	<form action="" method="post">
	  <div class="imgcontainer">
		<img src="img/logo.png" alt="FoodHub" class="avatar">
	  </div>

	  <div class="container">
		<label for="uname"><b>Username</b></label>
		<input type="text" placeholder="Enter Username" name="uname" required>

		<label for="psw"><b>Password</b></label>
		<input type="password" placeholder="Enter Password" name="psw" required>
			
		<button type="submit" name="confirm">Sign In</button>
		<p>or</p>
		<div class="signup">
			<a href="signup.php">Sign Up</a>
		</div>
	  </div>
</form>
</div>

</body>
</html>