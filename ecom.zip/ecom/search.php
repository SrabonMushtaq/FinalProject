<?php
	include('header.php');
	$srcMsg = 0;
	if(isset($_GET['searchquery'])){
		$searchquery = trim($_GET['query']);
		if(isset($searchquery)){

			$searchquery = mysqli_real_escape_string($conn, $searchquery);
			$foodSearch = "SELECT * FROM food_info where food_name LIKE '%{$searchquery}%'";
			$searchResult = mysqli_query($conn, $foodSearch);
			if(mysqli_num_rows($searchResult) > 0){
				$srcMsg = 1;
			}
			if(mysqli_num_rows($searchResult) == 0){
				$srcMsg = 3;
			}
		}
		if(empty($searchquery)){
			$srcMsg = 2;
		}
	}
	
?>


<head>
	<meta charset="UTF-8">
	<title>Search</title>
	<link rel="stylesheet" href="css/search.css">
</head>
<div class="searchr">
	<div class="search-heading">
		<?php
			if($srcMsg==1){
				?>
					<p class="phead"><?php echo mysqli_num_rows($searchResult); ?> Result<?php 
						if(mysqli_num_rows($searchResult) > 1){
							echo "s";
						}

					?> found for '<?php echo $searchquery; ?>'</p>
				<?php
			}
			elseif($srcMsg==2){
				echo "<h2 align='center'>Please Input some text</h2>";
			}

			elseif($srcMsg==3){

							echo "<h2 color='grey' align='center'>No result found for '".$searchquery."'</h2>";
			}
			elseif($srcMsg==0){

							echo "<h2 align='center' style='color: gray'>What are you looking for just input value and hit SEARCH button</h2>";
			}

		?>
		

	</div>
	<?php
		if($srcMsg==1){
			while($searchFood = mysqli_fetch_assoc($searchResult)){

	?>
	<div class="search-result">
		<div class="result-img">
			<img src="admin/uploads/<?php echo $searchFood['food_image']; ?>" alt="">
		</div>
		<div class="result-des">
			<a href="viewfood.php?foodid=<?php echo $searchFood['food_id']; ?>" class="s-nsme"><?php echo ucwords($searchFood['food_name']); ?></a>
			<p class="pprice">BDT <?php echo $searchFood['food_price']; ?> TK</p>
			<a href="checkout.php?id=<?php echo $searchFood['food_id']; ?>" class="checkout">Checkout</a>
		</div>
	</div>
			
	
	<?php
			}

		}
	?>
</div>