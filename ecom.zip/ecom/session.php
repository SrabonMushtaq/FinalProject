<?php
   include('conn.php');
   session_start();
   if(isset($_SESSION['uname'])){


   $user_check = $_SESSION['uname'];
   
   $ses_sql = mysqli_query($conn,"select * from user_info where user_name = '$user_check' ");
   
   $user_row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $user_name = $user_row['user_name'];
   $user_id = $user_row['user_id'];
   $user_mail = $user_row['user_mail'];
  } 
   
?>