<?php
	include('conn.php');
	include('session.php');
	$sprob = 0;
	$squery = "";


?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/header.css" media="all" />

</head>
<body>

<div class="top-content">
		<div class="logo">
			<img src="img/logo.png" alt="FoodHub">
		</div>
		<div class="search">
				<form action="search.php" method="get">
						<input type="text" name="query" placeholder="What Are You Looking For?">
						<input type="submit" name="searchquery" value="Search">
				</form>
		</div>
		<div class="top-userpanel">
			<ul>
		<?php
			if(isset($_SESSION['uname'])){
				?>
				<li><a href="profile.php?id=<?php echo $user_id; ?>"><?php echo ucwords($user_name); ?></a></li>
				<li><a href="logout.php">Sign Out</a></li>
				<?php

   			}
   			else{
   				?>
				<li><a href="login.php">Sign In</a></li>
				<li><a href="signup.php">Sign Up</a></li>
   				<?php
   			}

		?>
		
		  
		</ul>
	</div>
</div>
<div class="header_container">
  <img src="img/banner2.png" alt="Banner">
  <div class="header_content">
    <div class="slogan">
		Here Is Slogan
	</div>

    <div class="menubar">
		<ul>
		  <li><a href="index.php">Home</a></li>
		  <!-- <li><a href="">News</a></li> -->
		  <li><a href="">Contact</a></li>
		  <li><a href="">About</a></li>
		</ul>
	</div>

  </div>
</div>

</body>
</html>
