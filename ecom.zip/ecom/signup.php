<?php
	if(isset($_POST['signup'])){

		$errmsg = 0;
		$invalid = "`";

		$mail = trim($_POST['email']);
		$uname = trim($_POST['username']);
		$pass = trim($_POST['upass']);
		$cpass = trim($_POST['cpass']);



		if(empty($mail)){
			$errmsg = 1;
			$invalid = $invalid."Email must be required!\n";
		}
		if(!empty($mail)){
		    if(!filter_var($mail, FILTER_VALIDATE_EMAIL)){
		      $invalid = $invalid."Invalid Email adress!\n";
		      $errmsg = 1;
		    }
		  }

		if(empty($uname)){
			$errmsg = 1;
			$invalid = $invalid."Name must be required!\n";


		}

		if((isset($pass)) or (isset($cpass))){
			if((empty($pass)) or (empty($cpass))){
				$errmsg = 1;
				$invalid = $invalid."Password must be required!\n";
			}
		}

		if((!empty($pass)) and (!empty($cpass))){
			
			if($pass != $cpass){
				$errmsg = 1;
				$invalid = $invalid."Password does not match!\n";
			}
		}

		
		
		if($errmsg == 1){
			$invalid = trim($invalid."`");
			echo "<script>alert(".$invalid.");</script>";
		}
		elseif($errmsg == 0){
			include('conn.php');
			$regQuery = "INSERT INTO user_info (user_name, user_mail, user_pass) VALUES ('$uname', '$mail', '$pass') ";
			if (mysqli_query($conn, $regQuery)) {
				echo "<script>alert('You have been successfully registerd! You are redirecting to login page');
					window.location.href='login.php';
					</script>";
				
			}

			else{
			echo "Error: " . $regQuery . "<br>" . mysqli_error($conn);
			}
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign up</title>
<link rel="stylesheet" href="css/signup.css">
</head>
<body>

<form action="" method="post">
  <div class="container">
  	<div class="imgcontainer">
		<img src="img/logo.png" alt="FoodHub" class="avatar">
	 </div>

    
    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email"
    >

    <label for="username"><b>User Name</b></label>
    <input type="text" placeholder="User Name" name="username"
    >

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="upass"
    >

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="cpass">
    
    <button type="submit" class="registerbtn" name="signup">Register</button>
  </div>
  
  <div class="container signin">
    <p>Already have an account? <a href="login.php">Sign in</a>.</p>
  </div>
</form>

</body>
</html>