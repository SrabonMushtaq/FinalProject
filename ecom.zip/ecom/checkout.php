<?php
	include('header.php');
	?>
	

	<?php
	if(isset($_REQUEST['id'])){
		$chkmsg = 0;

		if (isset($_POST['checkout'])){
			$errmsg = 0;
			$invalid = "`";
			$cemail = $_POST['cemail'];
			$cname = $_POST['cname'];
			$cid = $_POST['cid'];
			$cfoodid = $_POST['cfoodid'];
			$cadress = $_POST['cadress'];
			$ccontact = $_POST['ccontact'];
			$cbkash = $_POST['cbkash'];
			$cdate = date("Y-m-d");
			$cstatus = "pending";

			if (empty($cname)) {
				$errmsg = 1;
				$invalid = $invalid."Name must be required\n";
			}
			if (empty($cadress)) {
				$errmsg = 1;
				$invalid = $invalid."Please Give shipping adress\n";
			}
			if (empty($ccontact)) {
				$errmsg = 1;
				$invalid = $invalid."Contact Number must be required\n";
			}
			if(!empty($cemail)){
			    if(!filter_var($cemail, FILTER_VALIDATE_EMAIL)){
			      $invalid = $invalid."Invalid Email adress!\n";
			      $errmsg = 1;
			    }
		 	}
			if (empty($cbkash)) {
				$errmsg = 1;
				$invalid = $invalid."Please input BKash TNXID\n";
			}
			if($errmsg == 1){
			$invalid = trim($invalid."`");
			echo "<script>alert(".$invalid.");</script>";
			}
			elseif($errmsg ==0 ){
				$checkQuery = "INSERT INTO checkout (food_id, user_id, name, adress, contact, mail, status, checkdate, tnx) VALUES ('$cfoodid', '$cid', '$cname', '$cadress', '$ccontact', '$cemail', 'pending', '$cdate', '$cbkash')";
				if(mysqli_query($conn, $checkQuery)){
					$chkmsg = 1;
				}
			}
		}
		$prid = trim($_REQUEST['id']);
		$checkQuery = mysqli_query($conn, "select * from food_info where food_id = '$prid' ");
		if(mysqli_num_rows($checkQuery) == 1){
			$checkResult = mysqli_fetch_assoc($checkQuery);
			?>
			<!DOCTYPE html>
			<html lang="en">
			<head>
				<meta charset="UTF-8">
				<title>Checkout</title>
				<link rel="stylesheet" href="css/checkout.css">
			</head>

			<body>

				<?php
					if($chkmsg == 1){
						?>
						<div class="success">
							
							<p>Thank You! Your order has been successfully inserted! </p>
						</div>
						<?php
					}
				?>
				<div class="display">
					<h3>Procedure</h3>
					<p>Fill up all required field and pay with this number(01XXXXXXXXX)</p>
				</div>
				<?php
					if($chkmsg ==0){


				?>
				<div class="display">
					<h3>Product Information</h3>
					<label for="pname">Name: <?php echo $checkResult['food_name']; ?></label>
					<label for="pprice">Price: <?php echo $checkResult['food_price']; ?></label>
				</div>

				<div class="row">
				  <div class="col-75">
				    <div class="container">
				    	<form action="" method="post">
							<div class="row">
					          	<div class="col-50">
						            <h3>Billing Address</h3>
						            <label for="fname">Full Name</label>
						            <input type="text" id="fname" name="cname" value="<?php if(isset($user_name)){echo $user_name; } ?>"placeholder="Your Name">
						            <label for="email">Email(optional)</label>
						            <input type="text" id="email" name="cemail" value="<?php if(isset($user_name)){echo $user_mail; } ?>" placeholder="Enter Your email">
						            <label for="adr">Address</label>
						            <input type="text" id="adr" name="cadress" placeholder="Shipping Adress">
						            <label for="city">Contact</label>
						            <input type="text" id="city" name="ccontact" placeholder="Contact Info">
									<h3>Payment</h3>
						            <label for="cname">BKash Transaction ID</label>
						            <input type="text" id="cname" name="cbkash" placeholder="BKash TNXID">
						            <input type="hidden" name="cfoodid" value="<?php echo $checkResult['food_id']; ?>">
						            <input type="hidden" name="cid" value="<?php if(isset($user_id)){echo $user_id; } ?>">
					            </div>
							</div>
				        
				        <input type="submit" value="Continue to checkout" name="checkout" class="btn">
				      </form>
				    </div>
				  </div>
				  
				</div>
			<?php } ?>
			</body>
			</html>
			<?php

		}
	}
?>


