-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2018 at 06:58 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `id` int(255) NOT NULL,
  `uname` varchar(200) NOT NULL,
  `pass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`id`, `uname`, `pass`) VALUES
(1, 'tausif', 'hobeki'),
(2, 'Shiyam', 'bolod');

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE `checkout` (
  `id` int(255) NOT NULL,
  `food_id` varchar(20) NOT NULL,
  `user_id` varchar(25) NOT NULL,
  `name` varchar(255) NOT NULL,
  `adress` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `status` varchar(55) NOT NULL,
  `checkdate` varchar(55) NOT NULL,
  `tnx` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `checkout`
--

INSERT INTO `checkout` (`id`, `food_id`, `user_id`, `name`, `adress`, `contact`, `mail`, `status`, `checkdate`, `tnx`) VALUES
(2, '22', '1', 'srabon mushtaq', 'mirpur,dhaka,bangladesh', '01703715087', 'srabonmushtaq0@gmail.com', 'pending', '2018-12-16', 'erhuyrturyki'),
(3, '22', '1', 'srabon mushtaq', 'mirpur,dhaka,bangladesh', '01703715087', 'srabonmushtaq0@gmail.com', 'complete', '2018-12-16', 'erhuyrturyki'),
(4, '22', '11', 'srabon mushtaq', 'mirpur,dhaka,bangladesh', '01703715087', 'srabonmushtaq0@gmail.com', 'cancel', '2018-12-16', 'erhuyrturyki'),
(5, '21', '11', 'tausif', 'dhaka', '01703715087', 'tausif@gmail.com', 'cancel', '2018-12-16', 'erhuyrturyki');

-- --------------------------------------------------------

--
-- Table structure for table `food_info`
--

CREATE TABLE `food_info` (
  `food_id` int(255) NOT NULL,
  `food_name` varchar(10000) NOT NULL,
  `food_price` varchar(100) NOT NULL,
  `food_image` varchar(10000) NOT NULL,
  `food_image_size` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food_info`
--

INSERT INTO `food_info` (`food_id`, `food_name`, `food_price`, `food_image`, `food_image_size`) VALUES
(9, 'Burger', '320', '83330-spicy-lamb-burger-96199-1.jpeg', '681966'),
(10, 'Chiken', '180', '71990-chiken.jpg', '44868'),
(12, 'Noodles', '110', '85355-images4.jpg', '37807'),
(14, 'Pizza', '320', '53634-pizza.jpg', '17651'),
(16, 'Bang Bang', '560', '65404-Bang.jpg', '24573'),
(17, 'Swarma', '320', '78417-swarma.jpg', '23633'),
(18, 'Soup', '160', '41261-soup.jpg', '22547'),
(19, 'Nuggets', '120', '74057-images8.jpg', '9860'),
(20, 'Biriyani', '180', '57827-biriyani.jpg', '26443'),
(21, 'Sweet', '290', '96233-para sweet.jpg', '33036'),
(22, 'Chiken Fry', '100', '13127-dhiken.jpg', '13706');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `adress` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `name`, `age`, `adress`) VALUES
(2, 'Syed Mushtaq Hasan', '23', 'mirpur,dhaka,bangladesh'),
(3, 'Tausif Hasan', '20', 'Jajabor'),
(4, 'Siyam', '21', 'Dhaka'),
(5, 'Aman', '26', 'Mirpur'),
(6, 'Aman', '26', 'Mirpur'),
(7, 'robin', '21', 'raypur');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int(255) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `age` varchar(1000) NOT NULL,
  `adress` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `name`, `age`, `adress`) VALUES
(1, 'Tausif Opi', '20', 'jajabor');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_mail` varchar(55) NOT NULL,
  `user_pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `user_name`, `user_mail`, `user_pass`) VALUES
(1, 'Opi', 'sayhellotoopi@gmail.com', 'notin'),
(3, 'tedh', 'srabonmushtaq0@gmail.com', '12'),
(4, 'tdhth', 'ne@fjt.jhkl', '12'),
(5, 'tedh', 'srabonmushtaq0@gmail.com', '1'),
(11, 'tausif', 'tausif@gmail.com', 'hobeki');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `food_info`
--
ALTER TABLE `food_info`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `age` (`age`),
  ADD KEY `adress` (`adress`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`(767)),
  ADD KEY `age` (`age`(767)),
  ADD KEY `adress` (`adress`(767));

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_info`
--
ALTER TABLE `admin_info`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `checkout`
--
ALTER TABLE `checkout`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `food_info`
--
ALTER TABLE `food_info`
  MODIFY `food_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
